choco pack package-a\package-a.nuspec
choco pack package-b\package-b.nuspec
choco pack package-c\package-c.nuspec
(1..1000) | ForEach-Object -Parallel {
    $null = choco pack package-d\package-d.nuspec --version 1.0.$_
    $null = choco pack package-e\package-e.nuspec --version 1.0.$_
    $_
} -ThrottleLimit 20
mkdir a,b,c
Copy-Item package-a*.nupkg a
Copy-Item package-b*.nupkg a
Copy-Item package-c*.nupkg a
Copy-Item package-a*.nupkg b
Copy-Item package-b*.nupkg b
Copy-Item package-c*.nupkg b
Move-Item package-a*.nupkg c
Move-Item package-b*.nupkg c
Move-Item package-c*.nupkg c
$counter = 0
$Folders = @('a', 'b', 'c')
Get-ChildItem *.nupkg | ForEach-Object {
    Move-Item $_ $Folders[$counter % 3]
    $counter++
}
